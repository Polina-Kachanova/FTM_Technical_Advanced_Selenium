package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SentBannerPage extends AbstractPage {

    private static final String SENT_BANNER_LOCATOR = "//div[@id = 'b-compose__sent']";

    @FindBy(xpath = SENT_BANNER_LOCATOR)
    private WebElement sentBanner;

    public SentBannerPage() {
        super();
    }

    public boolean isSentBannerDisplayed() {
        WebDriverProvider.wait(sentBanner);
        return sentBanner.isDisplayed();
    }
}
