package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public abstract class AbstractPage {

    private static final String DRAFTS_BUTTON_LOCATOR = "//div[@data-id = '500001']";
    private static final String SENT_MAILS_BUTTON_LOCATOR = "//div[@data-id = '500000']";
    private static final String LOG_OUT_LINK_LOCATOR = "//*[@id = 'PH_logoutLink']";

    @FindBy(xpath = DRAFTS_BUTTON_LOCATOR)
    private WebElement draftsListButton;
    @FindBy(xpath = SENT_MAILS_BUTTON_LOCATOR)
    private WebElement sentListButton;
    @FindBy(xpath = LOG_OUT_LINK_LOCATOR)
    private WebElement logOutLink;

    private WebDriver driver;

    public AbstractPage() {
        driver = WebDriverProvider.getDriver();
        PageFactory.initElements(driver, this);
    }

    public MailsList openDraftsPage() {
        WebDriverProvider.wait(draftsListButton);
        draftsListButton.click();
        return new MailsList();
    }

    public MailsList openSentPage() {
        WebDriverProvider.wait(sentListButton);
        sentListButton.click();
        return new MailsList();
    }

    public void logOut() {
        logOutLink.click();
    }

    protected WebDriver getDriver() {
        return driver;
    }
}
