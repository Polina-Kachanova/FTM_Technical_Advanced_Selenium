package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MailsList extends AbstractPage {

    private static final String MAIL_ROW_LOCATOR = "//div[text() = '%s']";
    private static final String MAIL_SUBJECT_PATTERN = "//div[text() = '%s']//span";
    private static final String CONTAINER_LOCATOR = "//div[@id = 'b-letters']";

    public MailsList() {
        super();
    }

    @FindBy(xpath = CONTAINER_LOCATOR)
    private WebElement container;

    public boolean isMailRowDisplayed(String subject) {
        WebDriverProvider.wait(container);
        try {
            return getDriver().findElement(By.xpath(String.format(MAIL_SUBJECT_PATTERN, subject))).isDisplayed();
        } catch (NoSuchElementException ex) {
            return false;
        }
    }

    public OpenedLetterPage openMail(String subject) {
        WebDriverProvider.wait(container);
        WebElement mailRow = getDriver().findElement(By.xpath(String.format(MAIL_ROW_LOCATOR, subject)));
        mailRow.click();
        return new OpenedLetterPage();
    }
}
