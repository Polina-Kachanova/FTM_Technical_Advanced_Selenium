package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InboxPage extends AbstractPage {

    private static final String USER_MENU_PATTERN = "//*[@id = 'PH_user-email' and normalize-space(text()) = '%s']";
    private static final String WRITE_LETTER_BUTTON_LOCATOR = "//a[@data-name = 'compose' and @href]";

    @FindBy(xpath = WRITE_LETTER_BUTTON_LOCATOR)
    private WebElement newLetterButton;

    public InboxPage() {
        super();
    }

    public boolean isUserMenuTextDisplayed(String login, String extension) {
        return getDriver().findElement(By.xpath(String.format(USER_MENU_PATTERN, login + extension))).isDisplayed();
    }

    public OpenedLetterPage openNewLetterPage() {
        WebDriverProvider.wait(newLetterButton);
        newLetterButton.click();
        return new OpenedLetterPage();
    }
}
