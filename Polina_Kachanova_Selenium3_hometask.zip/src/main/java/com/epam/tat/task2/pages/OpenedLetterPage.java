package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OpenedLetterPage extends AbstractPage {

    private static final String DESTINATION_FIELD_LOCATOR = "//textarea[@data-original-name = 'To']";
    private static final String HEAD_WRAPPER_LOCATOR = "//span[@data-text]";
    private static final String SUBJECT_FIELD_LOCATOR = "//input[@name = 'Subject']";
    private static final String TEXT_FRAME_LOCATOR = "//td[contains(@class, 'mceIframeContainer')]/iframe";
    private static final String TEXT_FIELD_LOCATOR = "//body[@id = 'tinymce']";
    private static final String SAVE_DROPDOWN_LOCATOR = "//div[@data-group = 'save-more']";
    private static final String SAVE_DRAFT_BUTTON_LOCATOR = "//a[@data-name = 'saveDraft']";
    private static final String DRAFT_BANNER_LOCATOR = "//div[@data-mnemo = 'saveStatus' and @style != 'display:none;']";
    private static final String SEND_BUTTON_LOCATOR = "//div[@data-name = 'send']";

    @FindBy(xpath = DESTINATION_FIELD_LOCATOR)
    private WebElement destinationField;
    @FindBy(xpath = HEAD_WRAPPER_LOCATOR)
    private WebElement headWrapperField;
    @FindBy(xpath = SUBJECT_FIELD_LOCATOR)
    private WebElement subjectField;
    @FindBy(xpath = TEXT_FRAME_LOCATOR)
    private WebElement textFrame;
    @FindBy(xpath = TEXT_FIELD_LOCATOR)
    private WebElement textField;
    @FindBy(xpath = SAVE_DROPDOWN_LOCATOR)
    private WebElement saveDropdown;
    @FindBy(xpath = SAVE_DRAFT_BUTTON_LOCATOR)
    private WebElement saveDraftButton;
    @FindBy(xpath = DRAFT_BANNER_LOCATOR)
    private WebElement draftBanner;
    @FindBy(xpath = SEND_BUTTON_LOCATOR)
    private WebElement sendButton;

    public OpenedLetterPage fillMailFields(String destination, String subject, String text) {
        WebDriverProvider.wait(destinationField);
        destinationField.sendKeys(destination);
        subjectField.sendKeys(subject);
        getDriver().switchTo().frame(textFrame);
        textField.sendKeys(text);
        getDriver().switchTo().defaultContent();
        return this;
    }

    public boolean isDraftBannerDisplayed() {
        WebDriverProvider.wait(draftBanner);
        return draftBanner.isDisplayed();
    }

    public OpenedLetterPage saveDraft() {

        saveDropdown.click();
        saveDraftButton.click();
        return this;
    }

    public SentBannerPage sendLetter() {
        sendButton.click();
        return new SentBannerPage();
    }

    public String getDestination() {
        WebDriverProvider.wait(headWrapperField);
        return headWrapperField.getAttribute("data-text");
    }

    public String getSubject() {
        WebDriverProvider.wait(subjectField);
        return subjectField.getAttribute("value");
    }

    public String getText() {
        WebDriverProvider.wait(textFrame);
        getDriver().switchTo().frame(textFrame);
        String text = textField.getText();
        getDriver().switchTo().defaultContent();
        return text.trim();
    }
}
