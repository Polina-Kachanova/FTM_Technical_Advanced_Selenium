package com.epam.tat.task2.businessObjects;

public class Letter {

    private String destination;
    private String subject;
    private String text;

    public Letter() {
    }

    public Letter(String destination, String subject, String text) {
        this.destination = destination;
        this.subject = subject;
        this.text = text;
    }

    @Override
    public String toString() {
        return destination + " " + subject + " " + text;
    }
}
