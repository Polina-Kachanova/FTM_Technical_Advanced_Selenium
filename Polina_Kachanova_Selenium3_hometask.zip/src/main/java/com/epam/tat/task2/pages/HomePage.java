package com.epam.tat.task2.pages;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends AbstractPage {

    @FindBy(xpath = "//input[@name = 'login']")
    private WebElement loginField;
    @FindBy(xpath = "//input[@name = 'password']")
    private WebElement passwordField;
    @FindBy(xpath = "//form[@id = 'auth']//input[@type = 'submit']")
    private WebElement submitButton;

    public HomePage() {
        super();
    }

    public InboxPage logIn(String login, String password) {
        WebDriverProvider.wait(loginField);
        loginField.sendKeys(login);
        passwordField.sendKeys(password);
        submitButton.click();
        return new InboxPage();
    }

}
