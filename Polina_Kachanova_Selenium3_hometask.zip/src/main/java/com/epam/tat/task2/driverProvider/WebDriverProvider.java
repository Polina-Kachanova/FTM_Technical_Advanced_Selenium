package com.epam.tat.task2.driverProvider;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

public class WebDriverProvider {

    private static WebDriver driver;
    private static final String ARGUMENT = "start-maximized";

    private WebDriverProvider() {
    }

    public static WebDriver getDriver() {
        if (driver == null) {
            try {
                driver = initializeDriver();
            } catch (MalformedURLException e) {
                System.out.println(e.getLocalizedMessage());
            }
        }
        return driver;
    }

    public static void open(String url) {
        getDriver().get(url);
    }

    public static void exit() {
        getDriver().quit();
    }

    private static WebDriver initializeDriver() throws MalformedURLException {
        System.setProperty("webdriver.chrome.driver", "src\\main\\java\\com\\epam\\tat\\task2\\drivers\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments(ARGUMENT);
        WebDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return driver;
    }

    public static void wait(WebElement element) {
        new WebDriverWait(getDriver(), 30).until(ExpectedConditions.visibilityOf(element));
    }
}
