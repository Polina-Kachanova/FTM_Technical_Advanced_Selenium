package com.epam.tat.task2;

import com.epam.tat.task2.driverProvider.WebDriverProvider;
import com.epam.tat.task2.pages.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.util.UUID;

public class BasicMailRuTest {

    protected static final String URL = "https://mail.ru/";
    protected static final String LOGIN = "polina.kachanova.1996";
    protected static final String EXTENSION = "@mail.ru";
    protected static final String PASSWORD = "1qaz2WSX";
    protected static final String DESTINATION = "Pol_Ka@tut.by";
    protected static final String SUBJECT = UUID.randomUUID().toString();
    protected static final String TEXT = UUID.randomUUID().toString();

    protected HomePage homePage;
    protected InboxPage mailsPage;
    protected MailsList mailsListPage;
    protected OpenedLetterPage openedLetterPage;
    protected SentBannerPage sentBannerPage;

    @BeforeClass
    public void start() {
        WebDriverProvider.open(URL);
        System.out.println("Test started successfully");
    }


    @AfterClass
    public void finishTest() {
        WebDriverProvider.exit();
        System.out.println("Test finished successfully");
    }
}
