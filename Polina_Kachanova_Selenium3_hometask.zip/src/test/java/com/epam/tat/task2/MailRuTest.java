package com.epam.tat.task2;

import com.epam.tat.task2.businessObjects.Letter;
import com.epam.tat.task2.pages.HomePage;
import com.epam.tat.task2.pages.InboxPage;
import com.epam.tat.task2.pages.MailsList;
import com.epam.tat.task2.pages.OpenedLetterPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MailRuTest extends BasicMailRuTest {

    @Test(description = "Login to mail.ru")
    public void logIn() {
        homePage = new HomePage();
        mailsPage = homePage.logIn(LOGIN, PASSWORD);
        Assert.assertTrue(mailsPage.isUserMenuTextDisplayed(LOGIN, EXTENSION));
        System.out.println("Login to mail.ru performed successfully");
    }

    @Test(description = "Create new email and save as a draft", dependsOnMethods = "logIn")
    public void createEmailAndSaveAsDraft() {
        openedLetterPage = new InboxPage().openNewLetterPage();
        openedLetterPage.fillMailFields(DESTINATION, SUBJECT, TEXT).saveDraft();
        Assert.assertTrue(openedLetterPage.isDraftBannerDisplayed());
        System.out.println("New email is created and saved as draft");
    }

    @Test(description = "Verify that email is present in the 'Drafts' folder", dependsOnMethods = "createEmailAndSaveAsDraft")
    public void checkEmailPresentsInDrafts() {
        mailsListPage = new OpenedLetterPage().openDraftsPage();
        Assert.assertTrue(mailsListPage.isMailRowDisplayed(SUBJECT));
        System.out.println("Email is present in the 'Drafts' folder");
    }

    @Test(description = "Open current email and check all the fields", dependsOnMethods = "checkEmailPresentsInDrafts")
    public void openEmailAndCheckFields() {
        openedLetterPage = new MailsList().openMail(SUBJECT);
        Letter expectedLetter = new Letter(DESTINATION, SUBJECT, TEXT);
        Letter actualLetter = new Letter(openedLetterPage.getDestination(), openedLetterPage.getSubject(), openedLetterPage.getText());
        Assert.assertEquals(expectedLetter.toString(), actualLetter.toString());
        System.out.println("Mail contains valid information");
    }

    @Test(description = "Send email and verify that email is not present in the 'Drafts'", dependsOnMethods = "openEmailAndCheckFields")
    public void sendEmailAndCheckNotInDrafts() {
        sentBannerPage = new OpenedLetterPage().sendLetter();
        boolean isLetterSent = sentBannerPage.isSentBannerDisplayed();
        mailsListPage = sentBannerPage.openDraftsPage();
        Assert.assertFalse(mailsListPage.isMailRowDisplayed(SUBJECT) && !isLetterSent);
        System.out.println("Email is sent and email is deleted from 'Drafts' folder");
    }

    @Test(description = "Verify that email is present in the 'Sent'", dependsOnMethods = "sendEmailAndCheckNotInDrafts")
    public void verifySentFolder() {
        mailsListPage.openSentPage();
        Assert.assertTrue(mailsListPage.isMailRowDisplayed(SUBJECT));
        mailsListPage.openMail(SUBJECT);
        openedLetterPage.logOut();
        System.out.println("Email is present in 'Sent' folder");
    }
}
