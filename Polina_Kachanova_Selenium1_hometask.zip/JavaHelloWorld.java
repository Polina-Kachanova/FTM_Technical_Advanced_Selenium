package com.epam.ftm.demo1;

public class JavaHelloWorld {
public static void main(String[] args) {
		
		System.out.println("HelloWorld is ready!");
		System.out.println("HelloWorld next line!");
		new HelloWorldTestNG().test1Failed();
		new HelloWorldTestNG().test2();
	}
}
