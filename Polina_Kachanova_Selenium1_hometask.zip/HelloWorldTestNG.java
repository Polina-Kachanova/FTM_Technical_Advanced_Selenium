package com.epam.ftm.demo1;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HelloWorldTestNG {
	
	Object object = new Object();

	@Test
	public void test1Failed() {
		System.out.println("I'am Polina Kachanova: " + object.toString());
		Assert.assertTrue(false, "Error occurred! Test failed as expected! ");
	}

	@Test
	public void test2() {
		System.out.println("I'am object: " + object.toString());
	}
}
