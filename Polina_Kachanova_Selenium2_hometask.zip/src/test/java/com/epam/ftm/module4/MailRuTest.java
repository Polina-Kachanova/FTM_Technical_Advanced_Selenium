package com.epam.ftm.module4;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.UUID;


public class MailRuTest extends BasicMailRuTest {

    private static final String LOGIN = "polina.kachanova.1996";
    private static final String EXTENSION = "@mail.ru";
    private static final String PASSWORD = "1qaz2WSX";
    private static final String DESTINATION = "Pol_Ka@tut.by";
    private static final String SUBJECT = UUID.randomUUID().toString();
    private static final String TEXT = UUID.randomUUID().toString();

    private static final By LOGIN_FIELD_LOCATOR = By.xpath("//input[@name = 'login']");
    private static final By PASSWORD_FIELD_LOCATOR = By.xpath("//input[@name = 'password']");
    private static final By SUBMIT_BUTTON_LOCATOR = By.xpath("//form[@id = 'auth']//input[@type = 'submit']");
    private static final By USER_MENU_LINK_LOCATOR = By.xpath("//*[@id = 'PH_user-email' and normalize-space(text()) = '" + LOGIN + EXTENSION + "']");
    private static final By WRITE_LETTER_BUTTON_LOCATOR = By.xpath("//a[@data-name = 'compose' and @href]");
    private static final By DESTINATION_FIELD_LOCATOR = By.xpath("//textarea[@data-original-name = 'To']");
    private static final By SUBJECT_FIELD_LOCATOR = By.xpath("//input[@name = 'Subject']");
    private static final By TEXT_FRAME_LOCATOR = By.xpath("//td[@class = 'mceIframeContainer mceFirst mceLast']/iframe");
    private static final By SAVE_DROPDOWN_LOCATOR = By.xpath("//div[@data-group = 'save-more']");
    private static final By SAVE_DRAFT_BUTTON_LOCATOR = By.xpath("//a[@data-name = 'saveDraft']");
    private static final By DRAFT_BANNER_LOCATOR = By.xpath("//div[@data-mnemo = 'saveStatus' and @style != 'display:none;']");
    private static final By DRAFTS_BUTTON_LOCATOR = By.xpath("//div[@data-id = '500001']");
    private static final By MAIL_ROW_LOCATOR = By.xpath("//div[@class = 'b-datalist__body']/div[@data-bem='b-datalist__item']");
    private static final By DRAFT_CONTAINER_LOCATOR = By.xpath("//div[@class = 'b-datalist__body']");
    private static final By DRAFT_TEXT_LOCATOR = By.xpath("//div[@class = 'b-datalist__item__subj' and text() = '" + SUBJECT + "']//span");
    private static final By DRAFT_MAIL_DESTINATION_LOCATOR = By.xpath("./preceding-sibling::span[@data-text]");
    private static final By SENT_BANNER_LOCATOR = By.xpath("//div[@id = 'b-compose__sent']");
    private static final By SEND_BUTTON_LOCATOR = By.cssSelector("div[data-name = send]");
    private static final By SENT_MAILS_BUTTON_LOCATOR = By.cssSelector("a[href *= 'messages/sent']");
    private static final By TEXT_FIELD_LOCATOR = By.cssSelector(".mceContentBody.compose2");

    @Test(description = "Log in to the mail.ru")
    public void logIn() {

        new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(LOGIN_FIELD_LOCATOR));
        WebElement loginInput = driver.findElement(LOGIN_FIELD_LOCATOR);
        loginInput.clear();
        loginInput.sendKeys(LOGIN);
        WebElement passwordInput = driver.findElement(PASSWORD_FIELD_LOCATOR);
        passwordInput.clear();
        passwordInput.sendKeys(PASSWORD);
        WebElement submitButton = driver.findElement(SUBMIT_BUTTON_LOCATOR);
        submitButton.click();
        new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfAllElementsLocatedBy(USER_MENU_LINK_LOCATOR));
        String userEmail = driver.findElement(USER_MENU_LINK_LOCATOR).getText();
        Assert.assertEquals(userEmail, LOGIN + EXTENSION);
    }

    @Test(description = "Create new email and save as a draft", dependsOnMethods = {"logIn"})
    public void createEmailAndSaveAsDraft() {

        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(WRITE_LETTER_BUTTON_LOCATOR));
        WebElement writeLetterButton = driver.findElement(WRITE_LETTER_BUTTON_LOCATOR);
        writeLetterButton.click();
        new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfAllElementsLocatedBy(DESTINATION_FIELD_LOCATOR));
        WebElement destinationField = driver.findElement(DESTINATION_FIELD_LOCATOR);
        destinationField.sendKeys(DESTINATION);
        WebElement subjectField = driver.findElement(SUBJECT_FIELD_LOCATOR);
        subjectField.sendKeys(SUBJECT);
        WebElement iFrame = driver.findElement(TEXT_FRAME_LOCATOR);
        driver.switchTo().frame(iFrame);
        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(TEXT_FIELD_LOCATOR));
        WebElement textField = driver.findElement(TEXT_FIELD_LOCATOR);
        textField.sendKeys(TEXT);
        driver.switchTo().defaultContent();
        WebElement saveDraftDropdown = driver.findElement(SAVE_DROPDOWN_LOCATOR);
        saveDraftDropdown.click();
        WebElement saveDraftButton = driver.findElement(SAVE_DRAFT_BUTTON_LOCATOR);
        saveDraftButton.click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(DRAFT_BANNER_LOCATOR));
        WebElement expectedBanner = driver.findElement(DRAFT_BANNER_LOCATOR);
        Assert.assertTrue(expectedBanner.isDisplayed());
    }

    @Test(description = "Verify that email is present in the 'Drafts' folder", dependsOnMethods = "createEmailAndSaveAsDraft")
    public void checkEmailPresentsInDrafts() {

        WebElement draftsButton = driver.findElement(DRAFTS_BUTTON_LOCATOR);
        draftsButton.click();
        new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfAllElementsLocatedBy(MAIL_ROW_LOCATOR));
        WebElement draftDestination = driver.findElement(DRAFT_TEXT_LOCATOR);
        Assert.assertEquals(draftDestination.getText(), TEXT);
    }

    @Test(description = "Open current email and check all the fields", dependsOnMethods = "checkEmailPresentsInDrafts")
    public void openEmailAndCheckFields() {

        WebElement mailButton = driver.findElement(DRAFT_TEXT_LOCATOR);
        mailButton.click();
        new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfAllElementsLocatedBy(DESTINATION_FIELD_LOCATOR));
        WebElement destinationField = driver.findElement(DESTINATION_FIELD_LOCATOR);
        String actualDestination = destinationField.findElement(DRAFT_MAIL_DESTINATION_LOCATOR).getAttribute("data-text");
        Assert.assertEquals(actualDestination, DESTINATION);
        WebElement subjectField = driver.findElement(SUBJECT_FIELD_LOCATOR);
        Assert.assertEquals(subjectField.getAttribute("value"), SUBJECT);
        WebElement iFrame = driver.findElement(TEXT_FRAME_LOCATOR);
        driver.switchTo().frame(iFrame);
        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(TEXT_FIELD_LOCATOR));
        WebElement textField = driver.findElement(TEXT_FIELD_LOCATOR);
        Assert.assertEquals(textField.getText(), TEXT);
        driver.switchTo().defaultContent();
    }

    @Test(description = "Send email and verify that email is not present in the 'Drafts'", dependsOnMethods = "openEmailAndCheckFields")
    public void sendEmailAndCheckNotInDrafts() {

        WebElement sendButton = driver.findElement(SEND_BUTTON_LOCATOR);
        sendButton.click();
        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(SENT_BANNER_LOCATOR));
        driver.findElement(By.xpath("//body")).sendKeys("gd");
        new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfAllElementsLocatedBy(DRAFT_CONTAINER_LOCATOR));
        Assert.assertThrows(NoSuchElementException.class, () -> driver.findElement(DRAFT_TEXT_LOCATOR));
    }

    @Test(description = "Verify that email is present in the 'Sent'", dependsOnMethods = "sendEmailAndCheckNotInDrafts")
    public void verifySentFolder() {

        WebElement sentMailsButton = driver.findElement(SENT_MAILS_BUTTON_LOCATOR);
        sentMailsButton.click();
        new WebDriverWait(driver, 60).until(ExpectedConditions.presenceOfAllElementsLocatedBy(MAIL_ROW_LOCATOR));
        WebElement draftDestination = driver.findElement(DRAFT_TEXT_LOCATOR);
        Assert.assertEquals(draftDestination.getText(), TEXT);
    }
}

